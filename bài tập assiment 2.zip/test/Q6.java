package test;
import java.util.Scanner;
public class Q6 {
    public static void main(String[] args) {
       int numberofleap=0;

        for( int time = 101; time <= 2100; time++ ){
            if( time % 4 ==0|| time % 100 !=0 && time % 400 ==0 ){
                System.out.print(time + " ");
                numberofleap++;
                if(numberofleap %10 ==0){
                    System.out.println();

                }


            }

        }
        System.out.println("the total number of leap years during this period :" + numberofleap);
        //cho biến number cộng 10 cho mõi lần chạy tiếp
        //nhập for làm sao mà mỗi khi nhập vào là nó sẽ cộng 10 cho mỗi vòng lập

    }
}
