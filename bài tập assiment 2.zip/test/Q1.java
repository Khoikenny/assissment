package test;

import java.util.Scanner;

          public class Q1 {
  public static void main(String[] args) {
         Scanner input = new Scanner(System.in);

         // Prompt the user to enter two cities
         System.out.print("Enter the three city name on seperate lines: ");
         String city1 = input.nextLine();

         String city2 = input.nextLine();

        String city3 = input.nextLine();
      if (city1.compareTo(city3)<0) {
          if (city1.compareTo(city2)<0) {
              System.out.println(city1 + ", " + city3 + " ," + city2);
          } else {
              System.out.println(city3 + " ," + city2 + ", " + city1);
          }
      } else {
          System.out.println(city2 + " ," + city1 + " ," + city3);
      }


         }
 }
