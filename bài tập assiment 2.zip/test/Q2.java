package test;

import java.util.ArrayList;
import java.util.Scanner;

public class Q2 {
    public static void main(String[] args) {
        // Sử dụng Scanner để nhận dữ liệu từ người dùng
        Scanner scanner = new Scanner(System.in);

        // Nhập dòng input đầu tiên
        System.out.print("Nhập dòng input đầu tiên: ");
        String input1 = scanner.nextLine();

        // Nhập dòng input thứ hai
        System.out.print("Nhập dòng input thứ hai: ");
        String input2 = scanner.nextLine();

        scanner.close(); // Đóng Scanner sau khi sử dụng

        // Tách từng từ từ dòng input đầu tiên và lưu vào danh sách
        ArrayList<String> words1 = splitStringIntoWords(input1);

        // Tách từng từ từ dòng input thứ hai và lưu vào danh sách
        ArrayList<String> words2 = splitStringIntoWords(input2);

        // Tìm và in các từ chung
        ArrayList<String> commonWords = findCommonWords(words1, words2);
        if (commonWords.isEmpty()) {
            System.out.println("Không có từ chung nào.");
        } else {
            System.out.println("Các từ chung là:");
            for (String word : commonWords) {
                System.out.println(word);
            }
        }
    }

    // Phương thức để tách từng từ từ chuỗi và trả về danh sách các từ
    private static ArrayList<String> splitStringIntoWords(String input) {
        ArrayList<String> words = new ArrayList<>();
        StringBuilder currentWord = new StringBuilder();

        for (int i = 0; i < input.length(); i++) {
            char currentChar = input.charAt(i);

            if (Character.isWhitespace(currentChar)) {
                if (currentWord.length() > 0) {
                    words.add(currentWord.toString());
                    currentWord.setLength(0);
                }
            } else {
                currentWord.append(currentChar);
            }
        }

        if (currentWord.length() > 0) {
            words.add(currentWord.toString());
        }

        return words;
    }

    // Phương thức để tìm và trả về danh sách các từ chung
    private static ArrayList<String> findCommonWords(ArrayList<String> words1, ArrayList<String> words2) {
        ArrayList<String> commonWords = new ArrayList<>();
        for (String word1 : words1) {
            for (String word2 : words2) {
                if (word1.equals(word2)) {
                    commonWords.add(word1);
                    break;
                }
            }
        }
        return commonWords;
    }
}
