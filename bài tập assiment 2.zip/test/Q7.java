package test;

import java.util.Scanner;


public class Q7 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        // Khởi tạo đối tượng Scanner để đọc dữ liệu từ bàn phím
        System.out.println("Please enter a line of input to analyze:");
        // Yêu cầu người dùng nhập một dòng văn bản và lưu vào biến "input"

        String input = scanner.nextLine().toLowerCase();
        // Chuyển dòng văn bản thành chữ thường để đảm bảo tính
        // nhất quán trong việc kiểm tra nguyên âm

        int[] count = new int[6];
        // Tạo một mảng có 6 phần tử để lưu trữ số lần xuất hiện của mỗi nguyên âm và ký tự 'y'

        for (int i = 0; i < input.length(); i++) {
            // Duyệt qua từng ký tự trong dòng văn bản

            char c = input.charAt(i);
            switch (c){
                case'a':
                    count[0]++;// if it find letter a in the input will go here and +1 for every it
                    //scan a from left to right
                    break;
                case'e':
                    count[1]++;
                    break;
                case'i':
                    count[2]++;
                    break;
                case'o':
                    count[3]++;
                    break;
                case'u':
                    count[4]++;
                    break;
                case'y':
                    count[5]++;
                    break;

            }

        }
        System.out.println("Vowel occurrence report:");
        System.out.println("a\t " + count[0]);
        System.out.println("e\t " + count[1]);
        System.out.println("i\t " + count[2]);
        System.out.println("o\t " + count[3]);
        System.out.println("u\t " + count[4]);
        System.out.println("y\t " + count[5]);
    }
}

