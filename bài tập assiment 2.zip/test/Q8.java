package test;

public class Q8 {
    public static void main(String[] args) {
        String text = "My goodness, that was a very, very funny story, wasn’t it?";

        // Tách chuỗi dựa trên dấu phẩy ","
        String fruits = text.replaceAll("[^a-zA-Z0-9]", " ");
        // Dấu ^ bên trong [] đại diện cho "không phải", nên [^a-zA-Z0-9]
//        a-z đại diện cho tất cả các chữ cái thường từ 'a' đến 'z'.
//                A-Z đại diện cho tất cả các chữ cái in hoa từ 'A' đến 'Z'.
//        0-9 đại diện cho tất cả các chữ số từ '0' đến '9'.
            System.out.print( fruits);
        }
    }
