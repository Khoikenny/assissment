package test;

import java.util.Scanner;


public class Q4 {
    public static void main(String[] args) {
        int value1;
        int value2;
        Scanner sc = new Scanner(System.in);
        System.out.println("enter low and high");
        value1 = sc.nextInt();
        value2= sc.nextInt();
        for (int i = value1; i <= value2; i++) {
            if (i % 2 != 0 && i % 5 != 0) {
                System.out.print(i);
                if (i != value2&& i!= value2-1 ) {
                    System.out.print(", " + i);
                }
            }
        }
    }
        }




