package test;

import java.util.Random;
import java.util.Scanner;

public class Q5 {
    public static void main(String[] args) {
        char leter;
        int number;
        Random rand = new Random();
        for( int i =0 ; i< 3;i++){
            number =rand.nextInt('Z' - 'A'+1) +'A';
            //có nghĩa là khi mà Z - A+1 thì nó bằng 25  mà ta biết A là bằng 65
             //mà từ a đến z là 90 tới 65 mà ta tính ra là trong khỏng đó có 25 đơn vị
            //cái số trở thành số tối đa mà nó sẽ tới là 65+25 = Z
            //khi mà chữ biến thành bất cứ chữ nào khác điều sẽ không biến bất cứ số chứ nào ta
            //to hơn số 90
            //it will get random the char from A to Z
            leter = (char) number;
            System.out.print(leter);


        }
        for(int i =0 ; i <3;i++){
            number= rand.nextInt(9);
            System.out.print(number);
        }


    }
}
